"""""
Problem Statement : Automate any cases that you would think are good to test the functionality
                    of validating logging into hudl.com with your credentials.

Analyst Name : Shagun Mahamuni
Emp id : 1514

System Requirements: installed selenium, python, pytest, pychram.
Language: Python
FrameWork:  Selenium
WebBrowser: Google Chrome
IDE : Pychram

Description: Below code test the functionality for hudl.com login page

Execution Method :
1.Right Click on file -> Open in Terminal .
2. executing cmd :  pytest file_name(test_part_A.py).py
"""



from selenium import webdriver       #importing wedrivers from selenium
import time
import pytest

""""test_setup() is created for intializing the web-browser,visiting hudl.com and closing the web-browser.
This method is executed each and everytime before executing the other test cases"""
@pytest.fixture()
def test_setup():
    global driver
    driver = webdriver.Chrome(executable_path="../A/chromedriver.exe")
    driver.implicitly_wait(10)
    driver.maximize_window()
    driver.get("https://www.hudl.com")
    time.sleep(2)
    yield
    driver.close()
    driver.quit()
    print("Test Completed...!")

# test_signup() is used to enter the signup page usign the X-path of page
def test_signup(test_setup):
    driver.find_element_by_xpath("/html/body/div[2]/header/div[2]/ul/li[2]/a").click()
    time.sleep(10)

# test_login_valid() is used to login by sending the valid Username and Password
# if the username and password are valid then coach will be able to enter the home page
def test_login_valid(test_setup):
    driver.find_element_by_xpath("/html/body/div[2]/header/div[2]/ul/li[3]/a").click()
    time.sleep(3)
    driver.find_element_by_id("email").send_keys("shagunmahamuni@rediffmail.com")
    driver.find_element_by_id("password").send_keys("9422606191Sm*")
    driver.find_element_by_id("logIn").click()
    time.sleep(10)
    driver.find_element_by_xpath("/html/body/div[2]/div/div[1]/nav[1]/div[4]/div[2]/div[1]/div[2]").click()
    time.sleep(5)
    driver.find_element_by_xpath("/html/body/div[2]/div/div[1]/nav[1]/div[4]/div[2]/div[2]/div[3]/a").click()
    time.sleep(10)

# test_login_invalid() is used to login by sending the invalid Username and Password
# if the username and password are invalid then coach will be not able to enter the home page
def test_login_invalid(test_setup):
    driver.find_element_by_xpath("/html/body/div[2]/header/div[2]/ul/li[3]/a").click()
    time.sleep(3)
    driver.find_element_by_id("email").send_keys("abc")
    driver.find_element_by_id("password").send_keys("1234")
    driver.find_element_by_id("logIn").click()
    time.sleep(10)

# test_need_help() is used to click on need help if the coach requires any kind help
# during logging-in
def test_need_help(test_setup):
    driver.find_element_by_xpath("/html/body/div[2]/header/div[2]/ul/li[3]/a").click()
    time.sleep(3)
    driver.find_element_by_id("forgot-password-link").click()
    time.sleep(10)

# test_temember_me() is used to save the username and password of the coach
# if the coach clicks on the Remember me checkbox=
def test_remember_me(test_setup):
    driver.find_element_by_xpath("/html/body/div[2]/header/div[2]/ul/li[3]/a").click()
    time.sleep(3)
    driver.find_element_by_xpath("/html/body/div[2]/form[1]/div[5]/div/label").click()
    time.sleep(5)

# test_login_with_Organization() is used for logging in with organization details
def test_login_with_organization(test_setup):
    driver.find_element_by_xpath("/html/body/div[2]/header/div[2]/ul/li[3]/a").click()
    time.sleep(3)
    driver.find_element_by_id("logInWithOrganization").click()
    time.sleep(10)








